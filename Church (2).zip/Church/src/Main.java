
import Home.HomePage;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Linus
 */
public class Main {

    public static void main(String[] args) {
        //Database application gui starts here.
        HomePage hp = new HomePage();
        hp.show();
    }
}
